<?php

return [
    'app_info' => [
        'api_id' => 28024112,
        'api_hash' => '098707f8afe13da59b658675af568b81',
    ],
    'logger' => [
        'logger' => 0,
    ],
    'print_update' => true,
];

